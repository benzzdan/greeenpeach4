<?php

/**
 * Character list for replacement in SEO URL's
 * @var array SEO replacement list
**/

$aSeoReplaceChars = array(
'¿' => '?',
'¡' => '!',
'á' => 'a',
'é' => 'e',
'í' => 'i',
'ó' => 'o',
'ú' => 'u',
'ü' => 'u',
'ñ' => 'n',
);
